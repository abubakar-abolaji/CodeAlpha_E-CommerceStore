const configuredApiUrl = window.NOVA_API_URL || document.querySelector('meta[name="nova-api-url"]')?.content;
const API_BASE_URL = (configuredApiUrl || (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1' ? 'http://localhost:5000/api' : '')).replace(/\/$/, '');

export async function apiRequest(path, options = {}) {
  if (!API_BASE_URL) throw new Error('The production API URL is not configured. Set window.NOVA_API_URL before loading the application.');
  const token = localStorage.getItem('nova_token');
  const headers = { ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }), ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  let response;
  try { response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers }); }
  catch { throw new Error('We could not connect to the store. Please check that the backend is running.'); }
  let data = null;
  try { data = await response.json(); } catch { if (!response.ok) throw new Error('The server returned an unreadable response.'); }
  if (!response.ok) {
    if (response.status === 401) { localStorage.removeItem('nova_token'); window.dispatchEvent(new Event('auth-expired')); }
    const message = data?.message || data?.error || ({400:'Please check the information entered.',403:'You do not have permission for this action.',404:'That item could not be found.',500:'Something went wrong on the server.'}[response.status] || 'Something went wrong.');
    throw new Error(message);
  }
  return data?.data ?? data;
}
export const API_URL = API_BASE_URL;