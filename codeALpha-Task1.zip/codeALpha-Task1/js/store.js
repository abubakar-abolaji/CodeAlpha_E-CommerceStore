const CART_KEY = 'nova_cart';
export const state = { products: [], cart: readCart(), user: null, lastOrder: null };
function readCart(){ try{return JSON.parse(localStorage.getItem(CART_KEY)) || []}catch{return []} }
export function saveCart(){localStorage.setItem(CART_KEY,JSON.stringify(state.cart));window.dispatchEvent(new Event('cart-updated'))}
export function cartCount(){return state.cart.reduce((sum,item)=>sum+item.quantity,0)}
export function cartSubtotal(){return state.cart.reduce((sum,item)=>sum+(Number(item.price)||0)*item.quantity,0)}
export function addToCart(product, quantity=1){const existing=state.cart.find(item=>item.id===product.id);if(existing) existing.quantity=Math.min(existing.quantity+quantity,product.stock||99);else state.cart.push({id:product.id,name:product.name,price:product.price,image:product.image,category:product.category,stock:product.stock||99,quantity});saveCart()}
export function updateQuantity(id,delta){const item=state.cart.find(entry=>entry.id===id);if(!item)return;item.quantity=Math.max(1,Math.min(item.quantity+delta,item.stock||99));saveCart()}
export function removeFromCart(id){state.cart=state.cart.filter(item=>item.id!==id);saveCart()}
export function clearCart(){state.cart=[];saveCart()}