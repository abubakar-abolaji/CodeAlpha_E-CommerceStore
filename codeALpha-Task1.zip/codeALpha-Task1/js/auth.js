import { apiRequest } from './api.js';
import { state } from './store.js';
export async function login(credentials){const data=await apiRequest('/auth/login',{method:'POST',body:JSON.stringify(credentials)});const token=data.token||data.accessToken;if(token)localStorage.setItem('nova_token',token);state.user=data.user||data.data?.user;return state.user}
export async function register(payload){return apiRequest('/auth/register',{method:'POST',body:JSON.stringify(payload)})}
export async function loadUser(){if(!localStorage.getItem('nova_token'))return null;try{const data=await apiRequest('/auth/me');state.user=data.user||data.data||data;return state.user}catch{return null}}
export function logout(){localStorage.removeItem('nova_token');state.user=null}