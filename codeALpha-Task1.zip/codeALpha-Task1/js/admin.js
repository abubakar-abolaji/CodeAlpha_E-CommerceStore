import { apiRequest } from './api.js';
import { state } from './store.js';
import { money, toast, setLoading, setError } from './ui.js';

const app = document.getElementById('app');

function adminRedirect() {
  if (!state.user) { toast('Please sign in to access the admin area.', 'error'); location.hash = 'login'; return true; }
  if (state.user.role !== 'admin') { toast('Administrator access required.', 'error'); location.hash = 'home'; return true; }
  return false;
}

function productRows(products) {
  return products.map(product => `<tr>
    <td><div class="admin-product"><img src="${product.images?.[0] || product.image || ''}" alt=""><div><strong>${product.name}</strong><small>${product.category}</small></div></div></td>
    <td>${money(product.price)}</td>
    <td><input class="stock-input" type="number" min="0" value="${product.stock}" data-stock-id="${product._id || product.id}" aria-label="Stock for ${product.name}"></td>
    <td><span class="status ${product.stock === 0 ? 'status-danger' : ''}">${product.stock === 0 ? 'Out of stock' : 'Available'}</span></td>
    <td><div class="admin-actions"><button class="button button-small button-outline" data-edit-product="${product._id || product.id}">Edit</button><button class="button button-small button-outline" data-save-stock="${product._id || product.id}">Save stock</button><button class="icon-button danger-button" data-delete-product="${product._id || product.id}" aria-label="Delete ${product.name}"><i class="fa-solid fa-trash"></i></button></div></td>
  </tr>`).join('');
}

function orderRows(orders) {
  return orders.map(order => `<tr>
    <td><strong>#${order._id || order.id}</strong><small>${new Date(order.createdAt).toLocaleDateString()}</small></td>
    <td>${order.user?.name || 'Customer'}<small>${order.user?.email || ''}</small></td>
    <td>${money(order.totalPrice ?? order.total ?? 0)}</td>
    <td><select class="select order-status" data-order-status="${order._id || order.id}" aria-label="Order status"><option ${order.orderStatus === 'Pending' ? 'selected' : ''}>Pending</option><option ${order.orderStatus === 'Processing' ? 'selected' : ''}>Processing</option><option ${order.orderStatus === 'Shipped' ? 'selected' : ''}>Shipped</option><option ${order.orderStatus === 'Delivered' ? 'selected' : ''}>Delivered</option><option ${order.orderStatus === 'Cancelled' ? 'selected' : ''}>Cancelled</option></select></td>
    <td><span class="status">${order.paymentStatus || 'Pending'}</span></td>
  </tr>`).join('');
}

export async function renderAdmin() {
  if (adminRedirect()) return;
  app.innerHTML = `<section class="admin-page container"><div class="account-head"><div><div class="eyebrow">NOVA / CONTROL ROOM</div><h1>Admin dashboard</h1></div><span class="status">Administrator</span></div><div id="admin-error"></div><div class="admin-stats" id="admin-stats"></div><div class="admin-grid"><section class="admin-panel"><div class="panel-head"><div><div class="eyebrow">CATALOG</div><h2>Products</h2></div><button class="button button-dark" id="toggle-product-form"><i class="fa-solid fa-plus"></i> Add product</button></div><form class="admin-form hidden" id="product-form"><div class="form-grid"><div class="field"><label for="admin-name">Name</label><input id="admin-name" name="name" required></div><div class="field"><label for="admin-category">Category</label><input id="admin-category" name="category" required></div><div class="field"><label for="admin-price">Price</label><input id="admin-price" name="price" type="number" min="0.01" step="0.01" required></div><div class="field"><label for="admin-stock">Stock</label><input id="admin-stock" name="stock" type="number" min="0" required></div><div class="field full"><label for="admin-image">Product image</label><input id="admin-image" name="image" type="file" accept="image/jpeg,image/png,image/webp,image/gif"><small class="admin-help">Upload an image up to 5 MB, or paste a URL below.</small><input id="admin-image-url" name="imageUrl" type="url" placeholder="https://..."></div><div class="field full"><label for="admin-description">Description</label><textarea id="admin-description" name="description" rows="3" required></textarea></div></div><div class="admin-preview" id="admin-preview"></div><button class="button button-orange" type="submit">Create product <i class="fa-solid fa-arrow-right"></i></button></form><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Product</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead><tbody id="admin-products"></tbody></table></div></section><section class="admin-panel"><div class="panel-head"><div><div class="eyebrow">FULFILLMENT</div><h2>All orders</h2></div></div><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Payment</th></tr></thead><tbody id="admin-orders"></tbody></table></div></section><section class="admin-panel"><div class="panel-head"><div><div class="eyebrow">CUSTOMERS</div><h2>Registered customers</h2></div></div><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Customer</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead><tbody id="admin-users"></tbody></table></div></section></div></section>`;
  const errorTarget = document.getElementById('admin-error');
  const productsTarget = document.getElementById('admin-products');
  const ordersTarget = document.getElementById('admin-orders');
  const usersTarget = document.getElementById('admin-users');
  setLoading(productsTarget, 'Loading catalog...');
  setLoading(ordersTarget, 'Loading orders...');
  setLoading(usersTarget, 'Loading customers...');
  try {
    const [productData, orderData, userData] = await Promise.all([apiRequest('/products?limit=50'), apiRequest('/admin/orders'), apiRequest('/admin/users')]);
    const products = productData.products || [];
    const orders = orderData.orders || [];
    const users = userData.users || [];
    productsTarget.innerHTML = products.length ? productRows(products) : '<tr><td colspan="5">No products found.</td></tr>';
    ordersTarget.innerHTML = orders.length ? orderRows(orders) : '<tr><td colspan="5">No orders found.</td></tr>';
    usersTarget.innerHTML = users.length ? users.map(user => `<tr><td><strong>${user.name}</strong></td><td>${user.email}</td><td><span class="status">${user.role}</span></td><td>${new Date(user.createdAt).toLocaleDateString()}</td></tr>`).join('') : '<tr><td colspan="4">No customers found.</td></tr>';
    document.getElementById('admin-stats').innerHTML = `<div class="admin-stat"><small>Products</small><strong>${products.length}</strong></div><div class="admin-stat"><small>Orders</small><strong>${orders.length}</strong></div><div class="admin-stat"><small>Low stock</small><strong>${products.filter(product => product.stock < 10).length}</strong></div><div class="admin-stat"><small>Pending payment</small><strong>${orders.filter(order => order.paymentStatus === 'Pending').length}</strong></div>`;
    bindAdminActions(products);
  } catch (error) { errorTarget.innerHTML = `<div class="form-error">${error.message}</div>`; productsTarget.innerHTML = ''; ordersTarget.innerHTML = ''; usersTarget.innerHTML = ''; }
}

function bindAdminActions(products) {
  document.getElementById('toggle-product-form').onclick = () => document.getElementById('product-form').classList.toggle('hidden');
  document.getElementById('product-form').onsubmit = async event => {
    event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget)); const button = event.currentTarget.querySelector('button[type="submit"]'); button.disabled = true;
    try { const imageFile = document.getElementById('admin-image').files[0]; const payload = imageFile ? new FormData() : { name: data.name, category: data.category, price: Number(data.price), stock: Number(data.stock), images: [data.imageUrl].filter(Boolean), description: data.description }; if (imageFile) { payload.append('image', imageFile); Object.entries({ name: data.name, category: data.category, price: Number(data.price), stock: Number(data.stock), description: data.description }).forEach(([key, value]) => payload.append(key, value)); } await apiRequest(imageFile ? '/products/upload' : '/products', { method: 'POST', body: imageFile ? payload : JSON.stringify(payload) }); toast('Product created'); renderAdmin(); } catch (error) { toast(error.message, 'error'); button.disabled = false; }
  };
  document.getElementById('admin-image').onchange = event => { const file = event.target.files[0]; if (file) { document.getElementById('admin-preview').innerHTML = `<img src="${URL.createObjectURL(file)}" alt="Selected product preview">`; } };
  document.querySelectorAll('[data-edit-product]').forEach(button => button.onclick = async () => { const product = products.find(item => String(item._id || item.id) === button.dataset.editProduct); if (!product) return; const name = prompt('Product name:', product.name); const price = prompt('Price:', product.price); const stock = prompt('Stock:', product.stock); if (name === null || price === null || stock === null) return; try { await apiRequest(`/products/${button.dataset.editProduct}`, { method: 'PUT', body: JSON.stringify({ name, price: Number(price), stock: Number(stock) }) }); toast('Product updated'); renderAdmin(); } catch (error) { toast(error.message, 'error'); } });
  document.querySelectorAll('[data-save-stock]').forEach(button => button.onclick = async () => { const input = document.querySelector(`[data-stock-id="${button.dataset.saveStock}"]`); try { await apiRequest(`/products/${button.dataset.saveStock}/stock`, { method: 'PATCH', body: JSON.stringify({ stock: Number(input.value) }) }); toast('Stock updated'); } catch (error) { toast(error.message, 'error'); } });
  document.querySelectorAll('[data-delete-product]').forEach(button => button.onclick = async () => { if (!confirm('Delete this product?')) return; try { await apiRequest(`/products/${button.dataset.deleteProduct}`, { method: 'DELETE' }); toast('Product deleted'); renderAdmin(); } catch (error) { toast(error.message, 'error'); } });
  document.querySelectorAll('[data-order-status]').forEach(select => select.onchange = async () => { try { await apiRequest(`/orders/${select.dataset.orderStatus}/status`, { method: 'PATCH', body: JSON.stringify({ orderStatus: select.value }) }); toast('Order status updated'); } catch (error) { toast(error.message, 'error'); renderAdmin(); } });
}
