import { apiRequest } from './api.js';
export async function getOrders(){const data=await apiRequest('/orders');return Array.isArray(data)?data:(data.orders||[])}
export async function getOrder(id){const data=await apiRequest(`/orders/${encodeURIComponent(id)}`);return data.order||data.data||data}
export async function createOrder(order){const data=await apiRequest('/orders',{method:'POST',body:JSON.stringify(order)});return data.order||data.data||data}