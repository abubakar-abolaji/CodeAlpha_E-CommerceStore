const mongoose = require('mongoose');

async function connectDatabase() {
  if (!process.env.MONGO_URI) throw new Error('MONGO_URI is not configured.');
  mongoose.set('strictQuery', true);
  await mongoose.connect(process.env.MONGO_URI, {
    serverSelectionTimeoutMS: 10000,
    connectTimeoutMS: 10000,
    socketTimeoutMS: 10000
  });
  console.log('MongoDB connected');
}

async function disconnectDatabase() {
  if (mongoose.connection.readyState) await mongoose.disconnect();
}

module.exports = { connectDatabase, disconnectDatabase };
