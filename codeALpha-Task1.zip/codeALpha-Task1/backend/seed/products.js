require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const mongoose = require('mongoose');
const Product = require('../models/Product');
const User = require('../models/User');
const { connectDatabase, disconnectDatabase } = require('../config/database');

const products = [
  ['Orbit Wireless Headphones','Immersive sound, soft memory foam, and 30 hours of quiet listening.',129,'Electronics',34,'https://images.unsplash.com/photo-1505740420928-5e560c06d30e'],
  ['Arc Mechanical Keyboard','A tactile aluminum keyboard for focused desks and long-form thinking.',96,'Electronics',22,'https://images.unsplash.com/photo-1587829741301-dc798b83add3'],
  ['Halo Desk Lamp','Warm, dimmable light with a weighted stone base.',78,'Home',18,'https://images.unsplash.com/photo-1507473885765-e6ed057f782c'],
  ['Field Canvas Tote','A structured everyday carryall in durable organic canvas.',52,'Accessories',40,'https://images.unsplash.com/photo-1544816155-12df9643f363'],
  ['Daybreak Sneakers','Lightweight everyday sneakers with a recycled knit upper.',118,'Shoes',27,'https://images.unsplash.com/photo-1542291026-7eec264c27ff'],
  ['Linen Overshirt','A relaxed layer cut from washed European linen.',88,'Fashion',16,'https://images.unsplash.com/photo-1596755389378-c31d21fd1273'],
  ['Cloud Knit Sweater','A soft merino blend sweater for slow mornings.',104,'Fashion',12,'https://images.unsplash.com/photo-1576566588028-4147f3842f27'],
  ['Ritual Ceramic Mug','Hand-finished stoneware with a generous morning handle.',28,'Home',55,'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d'],
  ['Calm Essential Oil Set','Three botanical blends for a quieter evening ritual.',36,'Beauty',31,'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108'],
  ['Fold Travel Bottle','A leakproof stainless bottle designed for lighter packing.',34,'Travel',44,'https://images.unsplash.com/photo-1602143407151-7111542de6e8'],
  ['Weekender Pack','A considered travel pack with a padded laptop sleeve.',142,'Travel',14,'https://images.unsplash.com/photo-1553062407-98eeb64c6a62'],
  ['Everyday Leather Belt','Full-grain leather with a low-profile solid brass buckle.',64,'Accessories',20,'https://images.unsplash.com/photo-1624222247344-550fb60583dc'],
  ['Studio Yoga Mat','Cushioned natural rubber mat with a calm textured grip.',74,'Wellness',25,'https://images.unsplash.com/photo-1592432678016-e910b452f9a2'],
  ['Cedar Grooming Kit','A compact set of cedar, sandalwood, and natural bristle tools.',48,'Beauty',19,'https://images.unsplash.com/photo-1621605815971-fbc98d665033'],
  ['Form Wool Throw','A generous wool throw in a warm neutral weave.',118,'Home',9,'https://images.unsplash.com/photo-1584100936595-c0654b55a2e2'],
  ['Minimal Card Holder','Slim vegetable-tanned leather with four card slots.',42,'Accessories',33,'https://images.unsplash.com/photo-1627123424574-724758594e93'],
  ['Trail Utility Shorts','Quick-dry stretch shorts for the city and beyond.',69,'Fashion',21,'https://images.unsplash.com/photo-1591195853828-11db59a44f6b'],
  ['Aero Running Shoes','Responsive daily trainers with a breathable mesh upper.',132,'Shoes',11,'https://images.unsplash.com/photo-1549298916-b41d501d3772']
].map(([name, description, price, category, stock, image], index) => ({ name, description, price, oldPrice: index % 3 === 0 ? price + 20 : undefined, category, stock, images: [`${image}?auto=format&fit=crop&w=900&q=80`], rating: 4 + ((index % 5) / 10), numReviews: 12 + index * 3, specifications: { Material: 'Thoughtfully selected materials', Warranty: '1 year limited warranty' } }));

async function seed() { await connectDatabase(); await Product.deleteMany({}); await Product.insertMany(products); if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD && !(await User.exists({ email: process.env.ADMIN_EMAIL }))) await User.create({ name: 'NOVA Admin', email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD, role: 'admin' }); console.log(`Seeded ${products.length} products`); await disconnectDatabase(); }
seed().catch(async error => { console.error(`Seeding failed: ${error.message}`); await disconnectDatabase(); process.exit(1); });
