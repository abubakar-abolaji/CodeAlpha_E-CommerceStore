const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 160 },
  description: { type: String, required: true, trim: true },
  price: { type: Number, required: true, min: 0.01 },
  oldPrice: { type: Number, min: 0 },
  category: { type: String, required: true, trim: true, index: true },
  images: [{ type: String, trim: true }],
  stock: { type: Number, required: true, min: 0, default: 0 },
  rating: { type: Number, min: 0, max: 5, default: 0 },
  numReviews: { type: Number, min: 0, default: 0 },
  specifications: { type: Map, of: String, default: {} }
}, { timestamps: true });

productSchema.virtual('image').get(function image() { return this.images?.[0] || ''; });
productSchema.set('toJSON', { virtuals: true });
productSchema.index({ name: 'text', description: 'text', category: 'text' });
module.exports = mongoose.model('Product', productSchema);
