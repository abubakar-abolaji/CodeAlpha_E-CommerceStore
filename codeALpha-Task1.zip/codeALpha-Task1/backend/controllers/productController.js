const Product = require('../models/Product');
const asyncHandler = require('../utils/asyncHandler');
const { validObjectId } = require('../middleware/validationMiddleware');

function productPayload(req) {
  const body = { ...req.body };
  if (req.file) body.images = [`${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`];
  else if (typeof body.images === 'string') body.images = [body.images];
  if (body.price !== undefined) body.price = Number(body.price);
  if (body.stock !== undefined) body.stock = Number(body.stock);
  return body;
}

const listProducts = asyncHandler(async (req, res) => {
  const { search, category, minPrice, maxPrice, minRating, sort = 'newest', page = 1, limit = 12 } = req.query;
  const filter = {};
  if (search) filter.$text = { $search: search };
  if (category) filter.category = new RegExp(`^${category.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i');
  if (minPrice || maxPrice) filter.price = { ...(minPrice ? { $gte: Number(minPrice) } : {}), ...(maxPrice ? { $lte: Number(maxPrice) } : {}) };
  if (minRating) filter.rating = { $gte: Number(minRating) };
  const safeLimit = Math.min(Math.max(Number(limit) || 12, 1), 50); const safePage = Math.max(Number(page) || 1, 1);
  const sortMap = { price_asc: { price: 1 }, price_desc: { price: -1 }, rating: { rating: -1, numReviews: -1 }, newest: { createdAt: -1 } };
  const [products, total] = await Promise.all([Product.find(filter).sort(sortMap[sort] || sortMap.newest).skip((safePage - 1) * safeLimit).limit(safeLimit), Product.countDocuments(filter)]);
  res.json({ success: true, message: 'Products retrieved successfully', data: { products, pagination: { page: safePage, limit: safeLimit, total, pages: Math.ceil(total / safeLimit) } } });
});
const getProduct = asyncHandler(async (req, res) => { validObjectId(req.params.id, 'product id'); const product = await Product.findById(req.params.id); if (!product) { const error = new Error('Product not found.'); error.statusCode = 404; throw error; } res.json({ success: true, message: 'Product retrieved successfully', data: product }); });
const createProduct = asyncHandler(async (req, res) => { const product = await Product.create(productPayload(req)); res.status(201).json({ success: true, message: 'Product created successfully', data: product }); });
const updateProduct = asyncHandler(async (req, res) => { validObjectId(req.params.id, 'product id'); const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true }); if (!product) { const error = new Error('Product not found.'); error.statusCode = 404; throw error; } res.json({ success: true, message: 'Product updated successfully', data: product }); });
const deleteProduct = asyncHandler(async (req, res) => { validObjectId(req.params.id, 'product id'); const product = await Product.findByIdAndDelete(req.params.id); if (!product) { const error = new Error('Product not found.'); error.statusCode = 404; throw error; } res.json({ success: true, message: 'Product deleted successfully', data: null }); });
const updateStock = asyncHandler(async (req, res) => { validObjectId(req.params.id, 'product id'); const stock = Number(req.body.stock); if (!Number.isInteger(stock) || stock < 0) { const error = new Error('Stock must be a non-negative integer.'); error.statusCode = 400; throw error; } const product = await Product.findByIdAndUpdate(req.params.id, { stock }, { new: true, runValidators: true }); if (!product) { const error = new Error('Product not found.'); error.statusCode = 404; throw error; } res.json({ success: true, message: 'Stock updated successfully', data: product }); });
const uploadProduct = createProduct;
module.exports = { listProducts, getProduct, createProduct, uploadProduct, updateProduct, deleteProduct, updateStock };
