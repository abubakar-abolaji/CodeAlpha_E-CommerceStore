const Order = require('../models/Order');
const Product = require('../models/Product');
const Cart = require('../models/Cart');
const asyncHandler = require('../utils/asyncHandler');
const { validObjectId } = require('../middleware/validationMiddleware');
const transitions = { Pending: ['Processing', 'Cancelled'], Processing: ['Shipped', 'Cancelled'], Shipped: ['Delivered'], Delivered: [], Cancelled: [] };

const createOrder = asyncHandler(async (req, res) => {
  const { items, orderItems, shippingAddress, customer, shipping } = req.body;
  const requestedItems = items || orderItems || [];
  const address = shippingAddress || { fullName: customer?.name, phone: customer?.phone, address: shipping?.address, city: shipping?.city, state: shipping?.state, country: shipping?.country, postalCode: shipping?.postalCode };
  const requiredAddress = ['fullName', 'phone', 'address', 'city', 'state', 'country', 'postalCode'];
  if (!Array.isArray(requestedItems) || !requestedItems.length || requiredAddress.some(field => !address?.[field])) { const error = new Error('Order items and complete shipping information are required.'); error.statusCode = 400; throw error; }
  const normalized = []; let subtotal = 0;
  for (const requested of requestedItems) { const id = requested.productId || requested.product; validObjectId(id, 'product id'); const quantity = Number(requested.quantity); if (!Number.isInteger(quantity) || quantity < 1) { const error = new Error('Each item quantity must be a positive integer.'); error.statusCode = 400; throw error; } const product = await Product.findById(id); if (!product) { const error = new Error('One of the requested products no longer exists.'); error.statusCode = 404; throw error; } if (quantity > product.stock) { const error = new Error(`${product.name} only has ${product.stock} units available.`); error.statusCode = 400; throw error; } subtotal += product.price * quantity; normalized.push({ product, quantity }); }
  const shippingFee = subtotal >= 75 ? 0 : 8; const discount = 0; const order = await Order.create({ user: req.user._id, orderItems: normalized.map(({ product, quantity }) => ({ product: product._id, name: product.name, quantity, price: product.price, image: product.images?.[0] || '' })), shippingAddress: address, subtotal, shippingFee, discount, totalPrice: subtotal + shippingFee - discount });
  for (const { product, quantity } of normalized) await Product.findByIdAndUpdate(product._id, { $inc: { stock: -quantity } });
  await Cart.findOneAndUpdate({ user: req.user._id }, { items: [] });
  res.status(201).json({ success: true, message: 'Order created successfully', data: order });
});
const getOrders = asyncHandler(async (req, res) => { const page = Math.max(Number(req.query.page) || 1, 1); const limit = Math.min(Math.max(Number(req.query.limit) || 10, 1), 50); const filter = { user: req.user._id }; const [orders, total] = await Promise.all([Order.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit), Order.countDocuments(filter)]); res.json({ success: true, message: 'Orders retrieved successfully', data: { orders, pagination: { page, limit, total, pages: Math.ceil(total / limit) } } }); });
const getOrder = asyncHandler(async (req, res) => { validObjectId(req.params.id, 'order id'); const filter = req.user.role === 'admin' ? { _id: req.params.id } : { _id: req.params.id, user: req.user._id }; const order = await Order.findOne(filter).populate('orderItems.product'); if (!order) { const error = new Error('Order not found.'); error.statusCode = 404; throw error; } res.json({ success: true, message: 'Order retrieved successfully', data: order }); });
const adminOrders = asyncHandler(async (req, res) => { const orders = await Order.find().populate('user', 'name email').sort({ createdAt: -1 }); res.json({ success: true, message: 'All orders retrieved successfully', data: { orders } }); });
const updateStatus = asyncHandler(async (req, res) => { validObjectId(req.params.id, 'order id'); const order = await Order.findById(req.params.id); if (!order) { const error = new Error('Order not found.'); error.statusCode = 404; throw error; } const nextStatus = req.body.orderStatus || req.body.status; if (!transitions[order.orderStatus]?.includes(nextStatus)) { const error = new Error(`Cannot move an order from ${order.orderStatus} to ${nextStatus}.`); error.statusCode = 400; throw error; } order.orderStatus = nextStatus; await order.save(); res.json({ success: true, message: 'Order status updated', data: order }); });
module.exports = { createOrder, getOrders, getOrder, adminOrders, updateStatus };
