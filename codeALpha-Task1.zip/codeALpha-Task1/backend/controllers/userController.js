const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const sanitizeUser = require('../utils/sanitizeUser');

const listUsers = asyncHandler(async (req, res) => {
  const users = await User.find().sort({ createdAt: -1 });
  res.json({ success: true, message: 'Customers retrieved successfully', data: { users: users.map(sanitizeUser) } });
});

module.exports = { listUsers };
