const User = require('../models/User');
const generateToken = require('../utils/generateToken');
const sanitizeUser = require('../utils/sanitizeUser');
const asyncHandler = require('../utils/asyncHandler');

const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || name.trim().length < 2 || !email || !password || password.length < 6) { const error = new Error('Name, valid email, and a password of at least 6 characters are required.'); error.statusCode = 400; throw error; }
  const existing = await User.findOne({ email: email.toLowerCase().trim() });
  if (existing) { const error = new Error('An account with this email already exists.'); error.statusCode = 409; throw error; }
  const user = await User.create({ name, email, password });
  res.status(201).json({ success: true, message: 'Registration successful', data: { user: sanitizeUser(user), token: generateToken(user) } });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: email?.toLowerCase().trim() }).select('+password');
  if (!user || !(await user.comparePassword(password || ''))) { const error = new Error('Invalid email or password.'); error.statusCode = 401; throw error; }
  res.json({ success: true, message: 'Login successful', data: { user: sanitizeUser(user), token: generateToken(user) } });
});

const me = asyncHandler(async (req, res) => res.json({ success: true, message: 'Current user retrieved', data: sanitizeUser(req.user) }));
module.exports = { register, login, me };
