const User = require('../models/User');
const generateToken = require('../utils/generateToken');
const sanitizeUser = require('../utils/sanitizeUser');
const asyncHandler = require('../utils/asyncHandler');
const createInitialAdmin = asyncHandler(async (req, res) => { const existing = await User.findOne({ email: process.env.ADMIN_EMAIL }); if (existing) return res.json({ success: true, message: 'Admin already exists', data: sanitizeUser(existing) }); const user = await User.create({ name: 'NOVA Admin', email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD, role: 'admin' }); res.status(201).json({ success: true, message: 'Admin created', data: { user: sanitizeUser(user), token: generateToken(user) } }); });
module.exports = { createInitialAdmin };
