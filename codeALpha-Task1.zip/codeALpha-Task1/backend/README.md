# NOVA Supply API

Express + MongoDB REST API for the CodeAlpha Simple E-commerce Store.

## Setup

1. Install Node.js 18+ and MongoDB.
2. Copy `.env.example` to `.env` and set `MONGO_URI`, `JWT_SECRET`, and `CLIENT_URL`.
3. Install dependencies and seed products:

```bash
cd backend
npm install
npm run seed
npm run dev
```

The API runs at `http://localhost:5000` by default.

## Render deployment

Create a Render Web Service with root directory `backend`, build command `npm install`, start command `npm start`, and health check path `/api/health`. Add all variables from `.env.example` in Render. Set `CLIENT_URL` to the deployed frontend origin. Add your Render API host to the frontend `nova-api-url` meta tag in the root `index.html`.

## API reference

All successful responses use `{ success: true, message, data }`; errors use `{ success: false, message }`.

- `POST /api/auth/register` with `{ name, email, password }`
- `POST /api/auth/login` with `{ email, password }`
- `GET /api/auth/me` with Bearer token
- `GET /api/products?search=&category=&minPrice=&maxPrice=&sort=price_asc&page=1&limit=12`
- `GET /api/products/:id`
- `POST /api/products`, `PUT /api/products/:id`, `DELETE /api/products/:id`, `PATCH /api/products/:id/stock` admin only
- `POST /api/products/upload` multipart form (`image` plus product fields) admin only
- `GET /api/cart`, `POST /api/cart` with `{ productId, quantity }`, `PUT /api/cart/:productId`, `DELETE /api/cart/:productId`, `DELETE /api/cart`
- `POST /api/orders` with `{ items: [{ productId, quantity }], shippingAddress }`
- `GET /api/orders`, `GET /api/orders/:id`
- `GET /api/admin/orders` and `PATCH /api/orders/:id/status` admin only
- `GET /api/admin/users` admin only
- `GET /api/health`

Order prices, shipping, discounts, stock, and totals are always calculated from MongoDB. Payment remains `Pending` until a real payment provider is integrated.
