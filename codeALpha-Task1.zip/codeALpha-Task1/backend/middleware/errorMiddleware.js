function notFound(req, res) { res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}` }); }
function errorHandler(error, req, res, next) {
  const status = error.statusCode || (error.name === 'ValidationError' ? 400 : error.code === 11000 ? 409 : 500);
  const message = status === 500 && process.env.NODE_ENV === 'production' ? 'Internal server error' : error.message;
  if (status === 500) console.error(error);
  res.status(status).json({ success: false, message, ...(error.details ? { details: error.details } : {}) });
}
module.exports = { notFound, errorHandler };
