const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');

const protect = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) { const error = new Error('Authentication required.'); error.statusCode = 401; throw error; }
  let payload;
  try { payload = jwt.verify(header.slice(7), process.env.JWT_SECRET); } catch { const error = new Error('Invalid or expired authentication token.'); error.statusCode = 401; throw error; }
  const user = await User.findById(payload.id);
  if (!user) { const error = new Error('Authenticated user no longer exists.'); error.statusCode = 401; throw error; }
  req.user = user;
  next();
});
const adminOnly = (req, res, next) => { if (req.user?.role !== 'admin') { const error = new Error('Administrator access required.'); error.statusCode = 403; return next(error); } next(); };
module.exports = { protect, adminOnly };
