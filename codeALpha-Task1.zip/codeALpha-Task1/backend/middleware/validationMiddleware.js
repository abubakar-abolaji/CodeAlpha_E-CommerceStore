function requireFields(fields) {
  return (req, res, next) => {
    const missing = fields.filter(field => req.body?.[field] === undefined || req.body[field] === null || req.body[field] === '');
    if (missing.length) { const error = new Error(`Missing required fields: ${missing.join(', ')}`); error.statusCode = 400; return next(error); }
    next();
  };
}
function validObjectId(value, label = 'id') { const mongoose = require('mongoose'); if (!mongoose.isValidObjectId(value)) { const error = new Error(`Invalid ${label}.`); error.statusCode = 400; throw error; } }
module.exports = { requireFields, validObjectId };
