function sanitizeUser(user) {
  const value = user.toObject ? user.toObject() : { ...user };
  delete value.password;
  return value;
}

module.exports = sanitizeUser;
