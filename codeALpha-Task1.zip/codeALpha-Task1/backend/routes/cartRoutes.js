const express = require('express');
const controller = require('../controllers/cartController');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();
router.use(protect);
router.route('/').get(controller.getCart).post(controller.addItem).delete(controller.clearCart);
router.route('/:productId').put(controller.updateItem).delete(controller.removeItem);
module.exports = router;
