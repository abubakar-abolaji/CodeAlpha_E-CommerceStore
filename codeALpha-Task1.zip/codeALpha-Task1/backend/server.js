require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const { connectDatabase } = require('./config/database');
const authRoutes = require('./routes/authRoutes');
const productRoutes = require('./routes/productRoutes');
const cartRoutes = require('./routes/cartRoutes');
const orderRoutes = require('./routes/orderRoutes');
const orderController = require('./controllers/orderController');
const userController = require('./controllers/userController');
const { protect, adminOnly } = require('./middleware/authMiddleware');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');

const app = express();
app.use('/uploads', express.static(require('path').join(__dirname, 'uploads')));
const allowedOrigins = (process.env.CLIENT_URL || 'http://localhost:4173').split(',').map(value => value.trim());
app.use(helmet());
app.use(cors({ origin: allowedOrigins, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
if (process.env.NODE_ENV !== 'test') app.use(morgan('dev'));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: true, legacyHeaders: false }));
app.get('/api/health', (req, res) => res.json({ success: true, message: 'NOVA Supply API is running', data: { environment: process.env.NODE_ENV || 'development' } }));
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
app.get('/api/admin/orders', protect, adminOnly, orderController.adminOrders);
app.get('/api/admin/users', protect, adminOnly, userController.listUsers);
app.use(notFound);
app.use(errorHandler);

if (require.main === module) {
  const port = process.env.PORT || 5000;
  connectDatabase().then(() => app.listen(port, () => console.log(`API listening on port ${port}`))).catch(error => { console.error(`Startup failed: ${error.message}`); process.exit(1); });
}
module.exports = app;
