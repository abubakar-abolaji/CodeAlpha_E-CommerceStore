# NOVA Supply

A responsive vanilla HTML, CSS, and JavaScript e-commerce frontend plus an Express/MongoDB REST API for CodeAlpha Task 1.

## Backend

The complete backend lives in [backend/README.md](backend/README.md). It provides JWT authentication, product search/filtering, user carts, server-calculated orders, stock management, admin product management, admin order management, validation, rate limiting, and centralized errors.

## Deploying on Render

Deploy the `backend` folder as a **Web Service**:

- Root directory: `backend`
- Build command: `npm install`
- Start command: `npm start`
- Health check path: `/api/health`

Set backend environment variables in Render: `NODE_ENV=production`, `MONGO_URI`, `JWT_SECRET`, `JWT_EXPIRES_IN`, `CLIENT_URL` (your Render Static Site URL), `ADMIN_EMAIL`, and `ADMIN_PASSWORD`. Run the seed command once from the backend shell with `npm run seed`.

Deploy the repository root as a **Static Site**:

- Build command: leave empty
- Publish directory: `.`

After Render gives the backend URL, update the `nova-api-url` meta tag in [index.html](index.html) to `https://your-backend.onrender.com/api`, then redeploy the static site. The API must also allow the static site URL through `CLIENT_URL`.

Render service disks are ephemeral. Product images uploaded through the admin page can disappear after a redeploy or restart; use Cloudinary, S3, or a Render persistent disk for production image storage.

## Run locally

Because the app uses ES modules, serve the folder with any static server:

```bash
npx serve .
```

Then open the printed local URL. A backend is expected at `http://localhost:5000/api` by default. Override it before loading the app with `window.NOVA_API_URL`, for example in the browser or by adding a small config script before `js/main.js`:

```html
<script>window.NOVA_API_URL = 'https://your-api.example.com/api';</script>
```

## Pages

- Home: featured products, categories, promotion, newsletter
- Shop: search, category/price/rating filters, sorting, wishlist, product cards
- Product detail: quantity, stock, specifications, related products
- Cart: guest localStorage cart, quantities, shipping, discount, total
- Login and register: API-connected authentication forms
- Checkout: customer and shipping form with backend order submission
- Confirmation and orders: post-purchase summary and authenticated order history

## API contract

The frontend uses `GET /products`, `GET /products/:id`, `POST /auth/register`, `POST /auth/login`, `GET /auth/me`, `POST /orders`, `GET /orders`, and `GET /orders/:id`. The API client adds a Bearer token from `localStorage` to authenticated requests and maps common HTTP/network errors to human-readable messages. Raw passwords are never stored.

## Technologies

HTML5, CSS3, ES6 modules, Fetch API, localStorage, Font Awesome, Google Fonts. No React, Angular, Vue, Bootstrap, or Tailwind.
Author
Abdulsalam Abubakar Abolaji
codeAlpha Intern